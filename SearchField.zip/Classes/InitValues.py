class InitValues():
    file_list = [
        "DataFile\MergeFile.filter.csv",
        "DataFile\MergeFile.mod.csv"
    ]

    file_name = "DataFile\MergeFile.filter.csv"